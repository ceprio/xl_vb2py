# << basesource declarations >>
from Tkinter import *

#
# VB constants
True = 1
False = 0
# -- end -- << basesource declarations >>
# << basesource methods >>
class App(Frame):
    # << class App declarations >>
    """The main form for the application"""
    # -- end -- << class App declarations >>

    # CODE_GOES_HERE
# -- end -- << basesource methods >>

if __name__ == '__main__':
    root = Tk()
    app = App(root)
    root.mainloop()
