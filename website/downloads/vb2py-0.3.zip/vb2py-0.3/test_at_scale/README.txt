This folder contains larger scale tests of code that has been found online.

The test files themselves should be automatically created by the scripts found here.

- clone_and_build.py: clones a github repo and then creates a test file
- file_tester.pt: base test class for testing files