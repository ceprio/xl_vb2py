This folder stores files that are submitted for testing by users of the online site
It should not be stored in the repository.